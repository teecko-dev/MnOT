﻿
namespace MnOT
{
	partial class HalUtama
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HalUtama));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.tabRangkuman = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.lblWRITE = new MetroFramework.Controls.MetroLabel();
            this.lblREAD = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.lblCHACE = new MetroFramework.Controls.MetroLabel();
            this.lblMEMAVA = new MetroFramework.Controls.MetroLabel();
            this.lblTHREADS = new MetroFramework.Controls.MetroLabel();
            this.lblHANDLE = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.circDISK = new CircularProgressBar.CircularProgressBar();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.circRAM = new CircularProgressBar.CircularProgressBar();
            this.circCPU = new CircularProgressBar.CircularProgressBar();
            this.tabINFORMASI = new MetroFramework.Controls.MetroTabPage();
            this.lstPerangkat = new MetroFramework.Controls.MetroListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.lstHDD = new MetroFramework.Controls.MetroListView();
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.lstMEMORY = new MetroFramework.Controls.MetroListView();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.metroTabPage3 = new MetroFramework.Controls.MetroTabPage();
            this.lstNET = new MetroFramework.Controls.MetroListView();
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.metroStyleManager1 = new MetroFramework.Components.MetroStyleManager(this.components);
            this.metroStyleExtender1 = new MetroFramework.Components.MetroStyleExtender(this.components);
            this.lbl1 = new MetroFramework.Controls.MetroLabel();
            this.lblFQDN = new MetroFramework.Controls.MetroLabel();
            this.lblCPUNAME = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pCPU = new System.Diagnostics.PerformanceCounter();
            this.pRAM = new System.Diagnostics.PerformanceCounter();
            this.pDISK = new System.Diagnostics.PerformanceCounter();
            this.pHANDLE = new System.Diagnostics.PerformanceCounter();
            this.pTHREADS = new System.Diagnostics.PerformanceCounter();
            this.pMEMAVA = new System.Diagnostics.PerformanceCounter();
            this.pCHACE = new System.Diagnostics.PerformanceCounter();
            this.pREADDISK = new System.Diagnostics.PerformanceCounter();
            this.pWRITEDISK = new System.Diagnostics.PerformanceCounter();
            this.lblCPUTEMP = new MetroFramework.Controls.MetroLabel();
            this.circCPUTEMP = new CircularProgressBar.CircularProgressBar();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.metroTabControl1.SuspendLayout();
            this.tabRangkuman.SuspendLayout();
            this.tabINFORMASI.SuspendLayout();
            this.metroTabPage1.SuspendLayout();
            this.metroTabPage2.SuspendLayout();
            this.metroTabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pCPU)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRAM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pDISK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pHANDLE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pTHREADS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMEMAVA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pCHACE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pREADDISK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pWRITEDISK)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(11, 15);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(307, 59);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Controls.Add(this.tabRangkuman);
            this.metroTabControl1.Controls.Add(this.tabINFORMASI);
            this.metroTabControl1.Controls.Add(this.metroTabPage1);
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Controls.Add(this.metroTabPage3);
            this.metroTabControl1.Location = new System.Drawing.Point(11, 100);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 0;
            this.metroTabControl1.Size = new System.Drawing.Size(779, 398);
            this.metroTabControl1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTabControl1.TabIndex = 0;
            this.metroTabControl1.UseSelectable = true;
            // 
            // tabRangkuman
            // 
            this.tabRangkuman.Controls.Add(this.metroLabel9);
            this.tabRangkuman.Controls.Add(this.metroLabel10);
            this.tabRangkuman.Controls.Add(this.lblWRITE);
            this.tabRangkuman.Controls.Add(this.lblREAD);
            this.tabRangkuman.Controls.Add(this.metroLabel8);
            this.tabRangkuman.Controls.Add(this.metroLabel7);
            this.tabRangkuman.Controls.Add(this.lblCHACE);
            this.tabRangkuman.Controls.Add(this.lblMEMAVA);
            this.tabRangkuman.Controls.Add(this.lblTHREADS);
            this.tabRangkuman.Controls.Add(this.lblHANDLE);
            this.tabRangkuman.Controls.Add(this.metroLabel6);
            this.tabRangkuman.Controls.Add(this.metroLabel5);
            this.tabRangkuman.Controls.Add(this.metroLabel4);
            this.tabRangkuman.Controls.Add(this.circDISK);
            this.tabRangkuman.Controls.Add(this.metroLabel3);
            this.tabRangkuman.Controls.Add(this.metroLabel1);
            this.tabRangkuman.Controls.Add(this.circRAM);
            this.tabRangkuman.Controls.Add(this.circCPU);
            this.tabRangkuman.HorizontalScrollbarBarColor = true;
            this.tabRangkuman.HorizontalScrollbarHighlightOnWheel = false;
            this.tabRangkuman.HorizontalScrollbarSize = 10;
            this.tabRangkuman.Location = new System.Drawing.Point(4, 38);
            this.tabRangkuman.Name = "tabRangkuman";
            this.tabRangkuman.Size = new System.Drawing.Size(771, 356);
            this.tabRangkuman.TabIndex = 0;
            this.tabRangkuman.Text = "Rangkuman";
            this.tabRangkuman.VerticalScrollbarBarColor = true;
            this.tabRangkuman.VerticalScrollbarHighlightOnWheel = false;
            this.tabRangkuman.VerticalScrollbarSize = 10;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(217, 295);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(117, 19);
            this.metroLabel9.TabIndex = 20;
            this.metroLabel9.Text = "Available Cached :";
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(217, 264);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(104, 19);
            this.metroLabel10.TabIndex = 19;
            this.metroLabel10.Text = "Available MEM :";
            // 
            // lblWRITE
            // 
            this.lblWRITE.AutoSize = true;
            this.lblWRITE.Location = new System.Drawing.Point(615, 295);
            this.lblWRITE.Name = "lblWRITE";
            this.lblWRITE.Size = new System.Drawing.Size(38, 19);
            this.lblWRITE.TabIndex = 18;
            this.lblWRITE.Text = "0 B/s";
            // 
            // lblREAD
            // 
            this.lblREAD.AutoSize = true;
            this.lblREAD.Location = new System.Drawing.Point(615, 263);
            this.lblREAD.Name = "lblREAD";
            this.lblREAD.Size = new System.Drawing.Size(38, 19);
            this.lblREAD.TabIndex = 17;
            this.lblREAD.Text = "0 B/s";
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(512, 295);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(89, 19);
            this.metroLabel8.TabIndex = 16;
            this.metroLabel8.Text = "Write Speed :";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(512, 264);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(87, 19);
            this.metroLabel7.TabIndex = 15;
            this.metroLabel7.Text = "Read Speed :";
            // 
            // lblCHACE
            // 
            this.lblCHACE.AutoSize = true;
            this.lblCHACE.Location = new System.Drawing.Point(333, 295);
            this.lblCHACE.Name = "lblCHACE";
            this.lblCHACE.Size = new System.Drawing.Size(16, 19);
            this.lblCHACE.TabIndex = 14;
            this.lblCHACE.Text = "0";
            // 
            // lblMEMAVA
            // 
            this.lblMEMAVA.AutoSize = true;
            this.lblMEMAVA.Location = new System.Drawing.Point(333, 263);
            this.lblMEMAVA.Name = "lblMEMAVA";
            this.lblMEMAVA.Size = new System.Drawing.Size(16, 19);
            this.lblMEMAVA.TabIndex = 13;
            this.lblMEMAVA.Text = "0";
            // 
            // lblTHREADS
            // 
            this.lblTHREADS.AutoSize = true;
            this.lblTHREADS.Location = new System.Drawing.Point(99, 295);
            this.lblTHREADS.Name = "lblTHREADS";
            this.lblTHREADS.Size = new System.Drawing.Size(0, 0);
            this.lblTHREADS.TabIndex = 12;
            // 
            // lblHANDLE
            // 
            this.lblHANDLE.AutoSize = true;
            this.lblHANDLE.Location = new System.Drawing.Point(99, 264);
            this.lblHANDLE.Name = "lblHANDLE";
            this.lblHANDLE.Size = new System.Drawing.Size(0, 0);
            this.lblHANDLE.TabIndex = 11;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(19, 295);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(62, 19);
            this.metroLabel6.TabIndex = 10;
            this.metroLabel6.Text = "Threads :";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(19, 264);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(57, 19);
            this.metroLabel5.TabIndex = 9;
            this.metroLabel5.Text = "Handle :";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(596, 219);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(35, 19);
            this.metroLabel4.TabIndex = 8;
            this.metroLabel4.Text = "DISK";
            // 
            // circDISK
            // 
            this.circDISK.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            this.circDISK.AnimationSpeed = 500;
            this.circDISK.BackColor = System.Drawing.Color.Transparent;
            this.circDISK.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.circDISK.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.circDISK.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.circDISK.InnerMargin = 2;
            this.circDISK.InnerWidth = -1;
            this.circDISK.Location = new System.Drawing.Point(512, 17);
            this.circDISK.MarqueeAnimationSpeed = 2000;
            this.circDISK.Name = "circDISK";
            this.circDISK.OuterColor = System.Drawing.Color.Gray;
            this.circDISK.OuterMargin = -25;
            this.circDISK.OuterWidth = 26;
            this.circDISK.ProgressColor = System.Drawing.Color.YellowGreen;
            this.circDISK.ProgressWidth = 25;
            this.circDISK.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.circDISK.Size = new System.Drawing.Size(200, 199);
            this.circDISK.StartAngle = 270;
            this.circDISK.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circDISK.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.circDISK.SubscriptText = "";
            this.circDISK.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circDISK.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.circDISK.SuperscriptText = "";
            this.circDISK.TabIndex = 7;
            this.circDISK.Text = "0.0%";
            this.circDISK.TextMargin = new System.Windows.Forms.Padding(8, 8, 0, 0);
            this.circDISK.Value = 68;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(360, 219);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(38, 19);
            this.metroLabel3.TabIndex = 6;
            this.metroLabel3.Text = "RAM";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(114, 219);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(35, 19);
            this.metroLabel1.TabIndex = 5;
            this.metroLabel1.Text = "CPU";
            // 
            // circRAM
            // 
            this.circRAM.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            this.circRAM.AnimationSpeed = 500;
            this.circRAM.BackColor = System.Drawing.Color.Transparent;
            this.circRAM.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.circRAM.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.circRAM.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.circRAM.InnerMargin = 2;
            this.circRAM.InnerWidth = -1;
            this.circRAM.Location = new System.Drawing.Point(276, 17);
            this.circRAM.MarqueeAnimationSpeed = 2000;
            this.circRAM.Name = "circRAM";
            this.circRAM.OuterColor = System.Drawing.Color.Gray;
            this.circRAM.OuterMargin = -25;
            this.circRAM.OuterWidth = 26;
            this.circRAM.ProgressColor = System.Drawing.Color.DeepSkyBlue;
            this.circRAM.ProgressWidth = 25;
            this.circRAM.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.circRAM.Size = new System.Drawing.Size(200, 199);
            this.circRAM.StartAngle = 270;
            this.circRAM.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circRAM.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.circRAM.SubscriptText = "";
            this.circRAM.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circRAM.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.circRAM.SuperscriptText = "";
            this.circRAM.TabIndex = 3;
            this.circRAM.Text = "0.0%";
            this.circRAM.TextMargin = new System.Windows.Forms.Padding(8, 8, 0, 0);
            this.circRAM.Value = 68;
            // 
            // circCPU
            // 
            this.circCPU.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            this.circCPU.AnimationSpeed = 500;
            this.circCPU.BackColor = System.Drawing.Color.Transparent;
            this.circCPU.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.circCPU.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.circCPU.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.circCPU.InnerMargin = 2;
            this.circCPU.InnerWidth = -1;
            this.circCPU.Location = new System.Drawing.Point(34, 17);
            this.circCPU.MarqueeAnimationSpeed = 2000;
            this.circCPU.Name = "circCPU";
            this.circCPU.OuterColor = System.Drawing.Color.Gray;
            this.circCPU.OuterMargin = -25;
            this.circCPU.OuterWidth = 26;
            this.circCPU.ProgressColor = System.Drawing.Color.Red;
            this.circCPU.ProgressWidth = 25;
            this.circCPU.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.circCPU.Size = new System.Drawing.Size(200, 199);
            this.circCPU.StartAngle = 270;
            this.circCPU.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circCPU.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.circCPU.SubscriptText = "";
            this.circCPU.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circCPU.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.circCPU.SuperscriptText = "";
            this.circCPU.TabIndex = 2;
            this.circCPU.Text = "0.0%";
            this.circCPU.TextMargin = new System.Windows.Forms.Padding(8, 8, 0, 0);
            this.circCPU.Value = 68;
            // 
            // tabINFORMASI
            // 
            this.tabINFORMASI.Controls.Add(this.lstPerangkat);
            this.tabINFORMASI.HorizontalScrollbarBarColor = true;
            this.tabINFORMASI.HorizontalScrollbarHighlightOnWheel = false;
            this.tabINFORMASI.HorizontalScrollbarSize = 10;
            this.tabINFORMASI.Location = new System.Drawing.Point(4, 38);
            this.tabINFORMASI.Name = "tabINFORMASI";
            this.tabINFORMASI.Size = new System.Drawing.Size(771, 356);
            this.tabINFORMASI.TabIndex = 1;
            this.tabINFORMASI.Text = "Informasi Perangkat";
            this.tabINFORMASI.VerticalScrollbarBarColor = true;
            this.tabINFORMASI.VerticalScrollbarHighlightOnWheel = false;
            this.tabINFORMASI.VerticalScrollbarSize = 10;
            // 
            // lstPerangkat
            // 
            this.lstPerangkat.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lstPerangkat.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lstPerangkat.FullRowSelect = true;
            this.lstPerangkat.GridLines = true;
            this.lstPerangkat.HideSelection = false;
            this.lstPerangkat.Location = new System.Drawing.Point(9, 4);
            this.lstPerangkat.Name = "lstPerangkat";
            this.lstPerangkat.OwnerDraw = true;
            this.lstPerangkat.ShowItemToolTips = true;
            this.lstPerangkat.Size = new System.Drawing.Size(753, 349);
            this.lstPerangkat.TabIndex = 2;
            this.lstPerangkat.UseCompatibleStateImageBehavior = false;
            this.lstPerangkat.UseSelectable = true;
            this.lstPerangkat.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Nama";
            this.columnHeader1.Width = 200;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Deskripsi";
            this.columnHeader2.Width = 300;
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.Controls.Add(this.lstHDD);
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.HorizontalScrollbarSize = 10;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(771, 356);
            this.metroTabPage1.TabIndex = 2;
            this.metroTabPage1.Text = "Informasi Hard Drive";
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            this.metroTabPage1.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.VerticalScrollbarSize = 10;
            // 
            // lstHDD
            // 
            this.lstHDD.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4});
            this.lstHDD.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lstHDD.FullRowSelect = true;
            this.lstHDD.GridLines = true;
            this.lstHDD.HideSelection = false;
            this.lstHDD.Location = new System.Drawing.Point(9, 4);
            this.lstHDD.Name = "lstHDD";
            this.lstHDD.OwnerDraw = true;
            this.lstHDD.ShowItemToolTips = true;
            this.lstHDD.Size = new System.Drawing.Size(753, 349);
            this.lstHDD.TabIndex = 3;
            this.lstHDD.UseCompatibleStateImageBehavior = false;
            this.lstHDD.UseSelectable = true;
            this.lstHDD.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Nama";
            this.columnHeader3.Width = 200;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Deskripsi";
            this.columnHeader4.Width = 300;
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.lstMEMORY);
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.HorizontalScrollbarSize = 10;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(771, 356);
            this.metroTabPage2.TabIndex = 3;
            this.metroTabPage2.Text = "Informasi Memory";
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.VerticalScrollbarSize = 10;
            // 
            // lstMEMORY
            // 
            this.lstMEMORY.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader6});
            this.lstMEMORY.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lstMEMORY.FullRowSelect = true;
            this.lstMEMORY.GridLines = true;
            this.lstMEMORY.HideSelection = false;
            this.lstMEMORY.Location = new System.Drawing.Point(9, 4);
            this.lstMEMORY.Name = "lstMEMORY";
            this.lstMEMORY.OwnerDraw = true;
            this.lstMEMORY.ShowItemToolTips = true;
            this.lstMEMORY.Size = new System.Drawing.Size(753, 349);
            this.lstMEMORY.TabIndex = 3;
            this.lstMEMORY.UseCompatibleStateImageBehavior = false;
            this.lstMEMORY.UseSelectable = true;
            this.lstMEMORY.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Nama";
            this.columnHeader5.Width = 200;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Deskripsi";
            this.columnHeader6.Width = 300;
            // 
            // metroTabPage3
            // 
            this.metroTabPage3.Controls.Add(this.lstNET);
            this.metroTabPage3.HorizontalScrollbarBarColor = true;
            this.metroTabPage3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.HorizontalScrollbarSize = 10;
            this.metroTabPage3.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage3.Name = "metroTabPage3";
            this.metroTabPage3.Size = new System.Drawing.Size(771, 356);
            this.metroTabPage3.TabIndex = 4;
            this.metroTabPage3.Text = "Informasi Perangkat Jaringan";
            this.metroTabPage3.VerticalScrollbarBarColor = true;
            this.metroTabPage3.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.VerticalScrollbarSize = 10;
            // 
            // lstNET
            // 
            this.lstNET.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader7,
            this.columnHeader8});
            this.lstNET.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lstNET.FullRowSelect = true;
            this.lstNET.GridLines = true;
            this.lstNET.HideSelection = false;
            this.lstNET.Location = new System.Drawing.Point(9, 4);
            this.lstNET.Name = "lstNET";
            this.lstNET.OwnerDraw = true;
            this.lstNET.ShowItemToolTips = true;
            this.lstNET.Size = new System.Drawing.Size(753, 349);
            this.lstNET.TabIndex = 3;
            this.lstNET.UseCompatibleStateImageBehavior = false;
            this.lstNET.UseSelectable = true;
            this.lstNET.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Nama";
            this.columnHeader7.Width = 200;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Deskripsi";
            this.columnHeader8.Width = 300;
            // 
            // metroStyleManager1
            // 
            this.metroStyleManager1.Owner = null;
            this.metroStyleManager1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroStyleManager1.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(324, 15);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(107, 19);
            this.lbl1.TabIndex = 2;
            this.lbl1.Text = "Nama Komputer";
            // 
            // lblFQDN
            // 
            this.lblFQDN.AutoSize = true;
            this.lblFQDN.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lblFQDN.Location = new System.Drawing.Point(324, 34);
            this.lblFQDN.Name = "lblFQDN";
            this.lblFQDN.Size = new System.Drawing.Size(120, 19);
            this.lblFQDN.TabIndex = 4;
            this.lblFQDN.Text = "Nama Komputer";
            // 
            // lblCPUNAME
            // 
            this.lblCPUNAME.AutoSize = true;
            this.lblCPUNAME.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lblCPUNAME.Location = new System.Drawing.Point(324, 78);
            this.lblCPUNAME.Name = "lblCPUNAME";
            this.lblCPUNAME.Size = new System.Drawing.Size(75, 19);
            this.lblCPUNAME.TabIndex = 8;
            this.lblCPUNAME.Text = "Processor";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(324, 59);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(66, 19);
            this.metroLabel2.TabIndex = 7;
            this.metroLabel2.Text = "Processor";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pCPU
            // 
            this.pCPU.CategoryName = "Processor";
            this.pCPU.CounterName = "% Processor Time";
            this.pCPU.InstanceName = "_Total";
            // 
            // pRAM
            // 
            this.pRAM.CategoryName = "Memory";
            this.pRAM.CounterName = "% Committed Bytes In Use";
            // 
            // pDISK
            // 
            this.pDISK.CategoryName = "PhysicalDisk";
            this.pDISK.CounterName = "Avg. Disk Queue Length";
            this.pDISK.InstanceName = "_Total";
            // 
            // pHANDLE
            // 
            this.pHANDLE.CategoryName = "Process";
            this.pHANDLE.CounterName = "Handle Count";
            this.pHANDLE.InstanceName = "_Total";
            // 
            // pTHREADS
            // 
            this.pTHREADS.CategoryName = "Process";
            this.pTHREADS.CounterName = "Thread Count";
            this.pTHREADS.InstanceName = "_Total";
            // 
            // pMEMAVA
            // 
            this.pMEMAVA.CategoryName = "Memory";
            this.pMEMAVA.CounterName = "Available MBytes";
            // 
            // pCHACE
            // 
            this.pCHACE.CategoryName = "Memory";
            this.pCHACE.CounterName = "Cache Bytes";
            // 
            // pREADDISK
            // 
            this.pREADDISK.CategoryName = "PhysicalDisk";
            this.pREADDISK.CounterName = "Disk Read Bytes/sec";
            this.pREADDISK.InstanceName = "_Total";
            // 
            // pWRITEDISK
            // 
            this.pWRITEDISK.CategoryName = "PhysicalDisk";
            this.pWRITEDISK.CounterName = "Disk Write Bytes/sec";
            this.pWRITEDISK.InstanceName = "_Total";
            // 
            // lblCPUTEMP
            // 
            this.lblCPUTEMP.AutoSize = true;
            this.lblCPUTEMP.BackColor = System.Drawing.Color.Transparent;
            this.lblCPUTEMP.Location = new System.Drawing.Point(704, 70);
            this.lblCPUTEMP.Name = "lblCPUTEMP";
            this.lblCPUTEMP.Size = new System.Drawing.Size(16, 19);
            this.lblCPUTEMP.TabIndex = 9;
            this.lblCPUTEMP.Text = "0";
            // 
            // circCPUTEMP
            // 
            this.circCPUTEMP.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            this.circCPUTEMP.AnimationSpeed = 500;
            this.circCPUTEMP.BackColor = System.Drawing.Color.Transparent;
            this.circCPUTEMP.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.circCPUTEMP.ForeColor = System.Drawing.Color.Black;
            this.circCPUTEMP.InnerColor = System.Drawing.Color.Transparent;
            this.circCPUTEMP.InnerMargin = 2;
            this.circCPUTEMP.InnerWidth = -1;
            this.circCPUTEMP.Location = new System.Drawing.Point(666, 24);
            this.circCPUTEMP.MarqueeAnimationSpeed = 2000;
            this.circCPUTEMP.Name = "circCPUTEMP";
            this.circCPUTEMP.OuterColor = System.Drawing.Color.Black;
            this.circCPUTEMP.OuterMargin = -25;
            this.circCPUTEMP.OuterWidth = 26;
            this.circCPUTEMP.ProgressColor = System.Drawing.Color.Red;
            this.circCPUTEMP.ProgressWidth = 25;
            this.circCPUTEMP.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 3.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.circCPUTEMP.Size = new System.Drawing.Size(111, 108);
            this.circCPUTEMP.StartAngle = 270;
            this.circCPUTEMP.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.circCPUTEMP.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circCPUTEMP.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.circCPUTEMP.SubscriptText = "";
            this.circCPUTEMP.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circCPUTEMP.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.circCPUTEMP.SuperscriptText = "°C";
            this.circCPUTEMP.TabIndex = 12;
            this.circCPUTEMP.Text = "0";
            this.circCPUTEMP.TextMargin = new System.Windows.Forms.Padding(8, 8, 0, 0);
            this.circCPUTEMP.Value = 68;
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel11.Location = new System.Drawing.Point(723, 70);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(23, 19);
            this.metroLabel11.TabIndex = 13;
            this.metroLabel11.Text = "°C";
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.Location = new System.Drawing.Point(517, 576);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(260, 19);
            this.metroLabel13.TabIndex = 14;
            this.metroLabel13.Text = "PT. MULTICOM PERSADA INTERNATIONAL";
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.Location = new System.Drawing.Point(15, 576);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(100, 19);
            this.metroLabel14.TabIndex = 15;
            this.metroLabel14.Text = "@2021 v 1.1 dev";
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.notifyIcon1.BalloonTipText = "MnOT";
            this.notifyIcon1.BalloonTipTitle = "MnOT";
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "MnOT v1.1 MUGEN@2021";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseDoubleClick);
            // 
            // HalUtama
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.metroLabel14);
            this.Controls.Add(this.metroLabel13);
            this.Controls.Add(this.metroLabel11);
            this.Controls.Add(this.lblCPUTEMP);
            this.Controls.Add(this.circCPUTEMP);
            this.Controls.Add(this.lblCPUNAME);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.lblFQDN);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.metroTabControl1);
            this.Controls.Add(this.pictureBox1);
            this.MaximizeBox = false;
            this.Name = "HalUtama";
            this.Resizable = false;
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "MnOT";
            this.Load += new System.EventHandler(this.HalUtama_Load);
            this.Resize += new System.EventHandler(this.HalUtama_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.metroTabControl1.ResumeLayout(false);
            this.tabRangkuman.ResumeLayout(false);
            this.tabRangkuman.PerformLayout();
            this.tabINFORMASI.ResumeLayout(false);
            this.metroTabPage1.ResumeLayout(false);
            this.metroTabPage2.ResumeLayout(false);
            this.metroTabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pCPU)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRAM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pDISK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pHANDLE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pTHREADS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMEMAVA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pCHACE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pREADDISK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pWRITEDISK)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage tabRangkuman;
        private MetroFramework.Controls.MetroTabPage tabINFORMASI;
        private MetroFramework.Components.MetroStyleManager metroStyleManager1;
        private MetroFramework.Components.MetroStyleExtender metroStyleExtender1;
        private MetroFramework.Controls.MetroLabel lbl1;
        private MetroFramework.Controls.MetroLabel lblFQDN;
        private MetroFramework.Controls.MetroLabel lblCPUNAME;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private System.Windows.Forms.Timer timer1;
        private System.Diagnostics.PerformanceCounter pCPU;
        private CircularProgressBar.CircularProgressBar circCPU;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private CircularProgressBar.CircularProgressBar circRAM;
        private System.Diagnostics.PerformanceCounter pRAM;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private CircularProgressBar.CircularProgressBar circDISK;
        private System.Diagnostics.PerformanceCounter pDISK;
        private MetroFramework.Controls.MetroLabel lblTHREADS;
        private MetroFramework.Controls.MetroLabel lblHANDLE;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private System.Diagnostics.PerformanceCounter pHANDLE;
        private System.Diagnostics.PerformanceCounter pTHREADS;
        private System.Diagnostics.PerformanceCounter pMEMAVA;
        private MetroFramework.Controls.MetroLabel lblMEMAVA;
        private MetroFramework.Controls.MetroLabel lblCHACE;
        private System.Diagnostics.PerformanceCounter pCHACE;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private System.Diagnostics.PerformanceCounter pREADDISK;
        private System.Diagnostics.PerformanceCounter pWRITEDISK;
        private MetroFramework.Controls.MetroLabel lblWRITE;
        private MetroFramework.Controls.MetroLabel lblREAD;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel lblCPUTEMP;
        private CircularProgressBar.CircularProgressBar circCPUTEMP;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroListView lstPerangkat;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroTabPage metroTabPage1;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private MetroFramework.Controls.MetroListView lstHDD;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private MetroFramework.Controls.MetroListView lstMEMORY;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private MetroFramework.Controls.MetroTabPage metroTabPage3;
        private MetroFramework.Controls.MetroListView lstNET;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
    }
}

